import pandas as pd

# 1. Load both sheets
xls = pd.ExcelFile("LUAD_expression_with_clinical.xlsx")
expr = pd.read_excel(xls, sheet_name="Expression")
clin = pd.read_excel(xls, sheet_name="Clinical")

# 2. Keep only LUAD samples
luad_cols = ["miRBaseName"] + [c for c in expr.columns if c.startswith("LUAD_")]
luad_expr = expr[luad_cols]

# 3. Transpose so rows = samples, columns = miRNAs
luad_expr = luad_expr.set_index("miRBaseName").T
luad_expr.reset_index(inplace=True)
luad_expr.rename(columns={"index": "Sample"}, inplace=True)

# 4. Merge with clinical data
clean_data = pd.merge(clin, luad_expr, on="Sample")

# 5. Save cleaned file
clean_data.to_excel("LUAD_cleaned.xlsx", index=False)
print("✅ Cleaning complete! File saved as LUAD_cleaned.xlsx")
