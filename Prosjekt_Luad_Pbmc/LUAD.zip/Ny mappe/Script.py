import pandas as pd
from lifelines import KaplanMeierFitter, statistics
import matplotlib.pyplot as plt
import os

# 1. Load cleaned data
df = pd.read_excel("LUAD_cleaned.xlsx")

# 2. Basic setup
time_col = "OS_days"          # survival time
status_col = None             # no status column (use median split for now)
miRNA_cols = df.columns[6:]   # all miRNA columns (after Smoking_Status)

# 3. Make output folder
os.makedirs("Survival_Plots", exist_ok=True)

# 4. Store results
results = []

# 5. Loop through miRNAs
for mir in miRNA_cols:
    try:
        # Split samples by median expression
        median_value = df[mir].median()
        high_group = df[df[mir] > median_value]
        low_group = df[df[mir] <= median_value]

        # Kaplan-Meier fitting
        kmf_high = KaplanMeierFitter()
        kmf_low = KaplanMeierFitter()

        kmf_high.fit(high_group[time_col], event_observed=None, label="High " + mir)
        kmf_low.fit(low_group[time_col], event_observed=None, label="Low " + mir)

        # Log-rank test
        result = statistics.logrank_test(
            high_group[time_col], low_group[time_col],
            event_observed_A=None, event_observed_B=None
        )

        p_value = result.p_value
        results.append({"miRNA": mir, "p_value": p_value})

        # Save plots for significant miRNAs
        if p_value < 0.05:
            plt.figure()
            kmf_high.plot()
            kmf_low.plot()
            plt.title(f"{mir} (p = {p_value:.4f})")
            plt.xlabel("Days")
            plt.ylabel("Survival probability")
            plt.tight_layout()
            plt.savefig(f"Survival_Plots/{mir}.png")
            plt.close()

    except Exception:
        continue

# 6. Save summary table
res_df = pd.DataFrame(results).sort_values("p_value")
res_df.to_excel("Significant_miRNAs.xlsx", index=False)

print("✅ Done! Check 'Significant_miRNAs.xlsx' and 'Survival_Plots/' for results.")
