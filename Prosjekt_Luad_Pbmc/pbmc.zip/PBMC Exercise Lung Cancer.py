import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt

# Load and prepare data
file_path = r"C:/Users/nthir/Documents/AI & Maskinlæring/PBMC_exercise_lung_cancer_datasets.xlsx"
excel_file = pd.ExcelFile(file_path)

# Identify DEG sheets
sheet_names = excel_file.sheet_names
deg_sheets = [s for s in sheet_names if 'top.table' in s.lower()]

# Load all DEG sheets
deg_data = {name: pd.read_excel(file_path, sheet_name=name) for name in deg_sheets}

# Create dictionaries to store filtered results
upregulated = {}
downregulated = {}

# Output directories
gene_list_dir = "filtered_gene_lists"
results_dir = "results/enrichment/pbmc"

os.makedirs(gene_list_dir, exist_ok=True)
os.makedirs(results_dir, exist_ok=True)

print("All sheets:", sheet_names)
print("DEG sheets:", deg_sheets)
print(deg_data['GSE111552.top.table'].head())

# Filter for DEGs
for name, df in deg_data.items():
    if {'logFC', 'adj.P.Val'}.issubset(df.columns):
        upregulated[name] = df[(df['logFC'] > 1) & (df['adj.P.Val'] < 0.05)]
        downregulated[name] = df[(df['logFC'] < -1) & (df['adj.P.Val'] < 0.05)]
    else:
        print(f"⚠️ Skipping {name}: required columns not found.")

# Save filtered data (CSV + TXT)
for name, df in upregulated.items():
    gene_col = [col for col in df.columns if 'gene' in col.lower()]
    if not gene_col:
        print(f"⚠️ Skipping {name}: no gene column found.")
        continue
    gene_col = gene_col[0]

    # Save text file (gene list)
    txt_path = os.path.join(gene_list_dir, f"{name}_upregulated.txt")
    df[gene_col].to_csv(txt_path, index=False, header=False)

    # Save CSV file
    csv_path = os.path.join(results_dir, f"{name}_upregulated.csv")
    df.to_csv(csv_path, index=False)

    print(f"✅ Saved: {csv_path} and {txt_path}")

for name, df in downregulated.items():
    gene_col = [col for col in df.columns if 'gene' in col.lower()]
    if not gene_col:
        print(f"⚠️ Skipping {name}: no gene column found.")
        continue
    gene_col = gene_col[0]

    # Save text file (gene list)
    txt_path = os.path.join(gene_list_dir, f"{name}_downregulated.txt")
    df[gene_col].to_csv(txt_path, index=False, header=False)

    # Save CSV file
    csv_path = os.path.join(results_dir, f"{name}_downregulated.csv")
    df.to_csv(csv_path, index=False)

    print(f"✅ Saved: {csv_path} and {txt_path}")

# Generate and save volcano plots
for name, df in deg_data.items():
    if {'logFC', 'adj.P.Val'}.issubset(df.columns):
        plt.figure(figsize=(6, 5))
        plt.scatter(df['logFC'], -np.log10(df['adj.P.Val']), color='gray', alpha=0.5)

        # Highlight up/downregulated genes
        plt.scatter(df[df['logFC'] > 1]['logFC'], -np.log10(df[df['logFC'] > 1]['adj.P.Val']), color='red', alpha=0.6, label='Up')
        plt.scatter(df[df['logFC'] < -1]['logFC'], -np.log10(df[df['logFC'] < -1]['adj.P.Val']), color='blue', alpha=0.6, label='Down')

        plt.axvline(x=1, color='black', linestyle='--', linewidth=1)
        plt.axvline(x=-1, color='black', linestyle='--', linewidth=1)
        plt.axhline(y=-np.log10(0.05), color='black', linestyle='--', linewidth=1)

        plt.title(f"Volcano Plot - {name}")
        plt.xlabel("log2 Fold Change")
        plt.ylabel("-log10 Adjusted P-value")
        plt.legend()

        plot_path = os.path.join(results_dir, f"{name}_volcano.png")
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"📈 Saved volcano plot: {plot_path}")

# Combine all DEGs across sheets
combined_up = pd.concat(upregulated.values(), ignore_index=True)
combined_down = pd.concat(downregulated.values(), ignore_index=True)

# Detect gene column automatically
gene_col_up = [col for col in combined_up.columns if 'gene' in col.lower()]
gene_col_down = [col for col in combined_down.columns if 'gene' in col.lower()]
if gene_col_up:
    gene_col_up = gene_col_up[0]
else:
    raise ValueError("❌ Could not find a gene column in upregulated data.")
if gene_col_down:
    gene_col_down = gene_col_down[0]
else:
    raise ValueError("❌ Could not find a gene column in downregulated data.")

# Save to desired output files
pbmc_up_txt = os.path.join(results_dir, "pbmc_up.txt")
pbmc_down_txt = os.path.join(results_dir, "pbmc_down.txt")
pbmc_up_csv = os.path.join(results_dir, "pbmc_up_GO.csv")
pbmc_down_csv = os.path.join(results_dir, "pbmc_down_GO.csv")

# Save gene lists (one gene per line, no header)
combined_up[gene_col_up].drop_duplicates().to_csv(pbmc_up_txt, index=False, header=False)
combined_down[gene_col_down].drop_duplicates().to_csv(pbmc_down_txt, index=False, header=False)

# Save full tables for GO analysis
combined_up.to_csv(pbmc_up_csv, index=False)
combined_down.to_csv(pbmc_down_csv, index=False)

print(f"✅ Saved: {pbmc_up_txt}")
print(f"✅ Saved: {pbmc_down_txt}")
print(f"✅ Saved: {pbmc_up_csv}")
print(f"✅ Saved: {pbmc_down_csv}")